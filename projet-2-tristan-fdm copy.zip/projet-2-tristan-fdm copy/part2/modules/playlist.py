from modules.song import Song
from typing import Iterator
import csv, json, random


class Playlist():
  def __init__(self, name: str, songs: list):
    if not name.startswith("Playlist-"):
      raise ValueError("Le nom de la Playlist doit commencer par 'Playlist-'.")
    self.__name = name

    if not all(isinstance(song, Song) for song in songs):
        raise ValueError("Tous les éléments de la liste songs doivent être des instances de Song.")
    self.__songs = {song.title: song for song in songs}

  @property
  def name(self):
      return self.__name

  @name.setter
  def name(self, new_name: str):
      if not new_name.startswith("Playlist-"):
          raise ValueError("Le nom de la Playlist doit commencer par 'Playlist-'.")
      self.__name = new_name

  @property
  def songs(self):
      return self.__songs

  @songs.setter
  def songs(self, new_songs: list):
      if not all(isinstance(song, Song) for song in new_songs):
          raise ValueError("Tous les éléments de la liste doivent être des instances de Song.")
      self.__songs = {song.title: song for song in new_songs}

  def __iter__(self) -> Iterator["Song"]:
    songs_list = list(self.__songs.values())
    return iter(songs_list)

  def __add__(self, song: "Song"):
    if isinstance(song, Song):
      self.__songs[song.title] = song
      return self
    else:
      raise TypeError(f"Impossible d'ajouter une chanson de type {type(song)}.")
  
  def __sub__(self, song_title: str):
    if song_title in self.__songs:
        del self.__songs[song_title]
    return self
  
  def play_all(self, rdm_mode: bool = False):
    mode = "aléatoire" if rdm_mode else "standard"
    print(f"Lecture de {self.__name} ({len(self.__songs)} chansons en mode {mode})")

    songs_list = list(self.__songs.values())
    
    if rdm_mode:
      played_songs = set()
      while len(played_songs) < len(songs_list):
        song = random.choice(songs_list)
        if song not in played_songs:
          song.play()
          played_songs.add(song)
    else:
      for song in songs_list:
        song.play()

  @classmethod
  def from_csv(cls, name: str, csv_path: str):
    if not name.startswith("Playlist-"):
      raise ValueError("Le nom de la Playlist doit commencer par 'Playlist-'.")
      
    songs = []
    try:
      with open(csv_path, mode='r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        for row in reader:
          song = Song.from_obj(row)  
          songs.append(song)
    except FileNotFoundError:
      raise FileNotFoundError(f"Le fichier {csv_path} est introuvable.")
    except Exception as e:
      raise Exception(f"Erreur lors de la lecture du fichier CSV : {e}")

    return cls(name, songs)
  
  @classmethod
  def from_json(cls, name: str, json_path: str):
    if not name.startswith("Playlist-"):
      raise ValueError("Le nom de la Playlist doit commencer par 'Playlist-'.")
    
    songs = []
    try:
      with open(json_path, mode='r', encoding='utf-8') as file:
        data = json.load(file) 
        for obj in data:
          song = Song.from_obj(obj) 
          songs.append(song)
    except FileNotFoundError:
      raise FileNotFoundError(f"Le fichier {json_path} est introuvable.")
    except json.JSONDecodeError:
      raise ValueError(f"Le fichier {json_path} contient un JSON invalide.")
    except Exception as e:
      raise Exception(f"Erreur lors de la lecture du fichier JSON : {e}")

    return cls(name, songs)
  
