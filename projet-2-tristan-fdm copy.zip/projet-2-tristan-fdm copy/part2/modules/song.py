import modules.instruments # used in from_obj() classmethod
from modules.instruments import Instrument
from datetime import datetime


from datetime import datetime
import modules.instruments  # Assurez-vous que ce module contient les classes Guitar, Piano, Drum

class Song:
  max_len_str_attr = 25

  def __init__(self, title: str, artist: str, release_year: int, instrument: Instrument):
    self.title = title
    self.artist = artist
    self.release_year = release_year
    self.instrument = instrument

  @property
  def title(self) -> str:
    return self.__title

  @title.setter
  def title(self, title: str):
    if not (0 <= len(title) <= Song.max_len_str_attr):
      raise ValueError(f"Le titre doit avoir une longueur entre 0 et {Song.max_len_str_attr}.")
    self.__title = title

  @property
  def artist(self) -> str:
    return self.__artist

  @artist.setter
  def artist(self, artist: str):
    if not (0 <= len(artist) <= Song.max_len_str_attr):
      raise ValueError(f"L'artiste doit avoir une longueur entre 0 et {Song.max_len_str_attr}.")
    self.__artist = artist

  @property
  def release_year(self) -> int:
    return self.__release_year

  @release_year.setter
  def release_year(self, release_year: int):
    current_year = datetime.now().year
    if not (0 <= release_year <= current_year):
      raise ValueError(f"L'année de sortie doit être entre 0 et {current_year}.")
    self.__release_year = release_year

  @property
  def instrument(self) -> Instrument:
    return self.__instrument

  @instrument.setter
  def instrument(self, instrument: Instrument):
    if not isinstance(instrument, Instrument):
      raise TypeError("L'instrument doit être de classe Instrument.")
    self.__instrument = instrument

  @classmethod
  def from_obj(cls, obj: dict):
    required_fields = ["title", "artist", "release_year", "instrument", "instrument_brand"]

    for field in required_fields:
      if field not in obj:
        raise ValueError(f"Impossible d'instancier une chanson depuis l'objet '{obj}'.")


    title = obj["title"]
    artist = obj["artist"]
    release_year = int(obj["release_year"])
    instrument_type = obj["instrument"]
    instrument_brand = obj["instrument_brand"]

    try:
      instrument_cls = getattr(modules.instruments, instrument_type)
    except AttributeError:
      raise ValueError(f"Type d'instrument '{instrument_type}' invalide ou non pris en charge.")

    instrument = instrument_cls(instrument_brand)

    return cls(title, artist, release_year, instrument)

  def __str__(self) -> str:
    return (
      f"Titre: {self.title}\n"
      f" Artiste: {self.artist}\n"
      f" Annee de sortie: {self.release_year}\n"
      f" Instrument: {self.instrument}"
    )

  def play(self):
    formatted_title = f"{self.title:<{Song.max_len_str_attr}}"
    print(f"Joue {formatted_title} solo avec", end=" ")
    self.instrument.play()
